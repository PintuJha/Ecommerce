import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ReturnpolicyComponent } from './home/returnpolicy/returnpolicy.component';
import { ProductsComponent } from './home/products/products.component';
import { BrandComponent } from './home/brand/brand.component';
import { BlogComponent } from './home/blog/blog.component';
import { CategoriesComponent } from './home/categories/categories.component';
import { TestimonialsComponent } from './home/testimonials/testimonials.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    ReturnpolicyComponent,
    ProductsComponent,
    BrandComponent,
    BlogComponent,
    CategoriesComponent,
    TestimonialsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
