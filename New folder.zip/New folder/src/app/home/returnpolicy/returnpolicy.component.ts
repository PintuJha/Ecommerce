import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-returnpolicy',
  templateUrl: './returnpolicy.component.html',
  styleUrls: ['./returnpolicy.component.less']
})
export class ReturnpolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
